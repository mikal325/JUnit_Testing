package task;

public class Task {
	
	private String taskID;
	private String name;
	private String description;
	
	public Task(String taskID, String name, String description) {
		if (taskID == null || taskID.length() > 10) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if (name == null || name.length() > 20) {
			throw new IllegalArgumentException("Invalid Input");
		}
		if (description == null || description.length() > 50)
	
	this.taskID = taskID;
	this.name = name;
	this.description = description;
	}
	
	public String getTaskID() {
		return taskID;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDesc() {
		return description;
	}
}
