package appointments;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

	@Test
	void testService() {
		AppointmentService as = new AppointmentService();
		assertTrue(as.add().equals("123456"));
	}

}
