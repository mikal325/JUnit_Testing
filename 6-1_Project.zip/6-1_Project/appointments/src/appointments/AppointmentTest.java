package appointments;

import static org.junit.api.assertions.*;

import org.junit.jupiter.api.Test;

class AppointmentTest{
	@Test
	void testAppointment(){
		
		Appointment app = new Appointment("123456789", 11/11/25,"a tested appointment");
		//testing appID
		assertTrue(app.getAppID().equals("12345676891"));
		assertTrue(app.getAppID().equals("123"));
		assertTrue(app.getAppID().equals(124));
		//testing date
		assertTrue(app.getDate().equals(11/11/25));
		assertTrue(app.getDate().equals(1/1/25));
		//testing description aka desc
		assertTrue(app.getDesc().equals("description"));
		assertTrue(app.getDesc().equals("this is a really long description that i hope will be over fifty characters when im done writing this!!!!!"));
	}
}
