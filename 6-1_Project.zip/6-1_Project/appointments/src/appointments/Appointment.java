package appointments;

import java.util.Date;

public class Appointment {
 	private String appID; //appointment ID 10 chars
	private Date date; //for today and future dates
	private String desc; //description 50 chars
	
	//setter methods
	public void setAppID(String appID) {
		if (appID == null || appID.length() > 10) {
			throw new IllegalArgumentException("Invalid Entry");
		}
		else {
			this.appID = appID;
		}
	}
	
	public void setDate(Date date) {
		if (date == null || before(date)) {
			throw new IllegalArgumentException("Invalid Entry");
		}
		else {
			this.date = date;
		}
	}
	public void setDesc(String desc) {
		if (desc == null || desc.length() > 50) {
			throw new IllegalArgumentException("Invalid Entry");
		}
		else {
			this.desc = desc;
		}
	}
	
	//getter methods
	public String getAppID(String appID) {
		return appID;
	}
	
	public Date getDate(Date date) {
		return date;
	}
	
	public String getDesc(String desc) {
		return desc;
	}
}
