package appointments;

import java.util.ArrayList;

public class AppointmentService {
	public void appointmentList() {
		ArrayList<String> list = new ArrayList<>();
		list.add(setAppID);
		
		list.remove(appID);
	}
}
