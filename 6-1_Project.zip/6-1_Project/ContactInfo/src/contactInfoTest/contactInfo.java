package contactInfoTest;

public class contactInfo {

}
