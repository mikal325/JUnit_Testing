package contactInfoTest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class contactInfoTest {

	@Test
	void ContactTest() {
		ContactInfo contactInfo = new ContactInfo("Michael","Armstrong","4752793072","133 main street");
		assertTrue(contactInfo.getFirstName().equals("Michael"));
		assertTrue(contactInfo.getLastName().equals("Armstrong"));
		assertTrue(contactInfo.getPhone().equals("4752793072"));
		assertTrue(contactInfo.getAddress().equals("133 main street"));
	}
}
  