/**
 * 
 */
/**
 * 
 */
module ContactInfo {
	requires org.junit.jupiter.api;
}