package contactInfo;

public class ContactInfo{
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	public ContactInfo(String firstName, String lastName, String phone, String address) {
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid input");
		}
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
}
